package com.cg.entities;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class AssessmentMain {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		
		EntityManagerFactory factory = 
				Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		AssessmentCalc ac=new AssessmentCalc();
		
		System.out.println("enter the trainee name");
		String trainee_name=sc.next();
		ac.setTrainee_name(trainee_name);
		
		System.out.println("enter the module name");
		String module_name=sc.next();
	ac.setModule_name(module_name);
	
	
	System.out.println("enter  mpt score");
	double mpt_score=sc.nextDouble();
	ac.setMpt_score(mpt_score);
	
	
	System.out.println("enter mtt score");
	double  mtt_score=sc.nextDouble();
	ac.setMtt_score(mtt_score);
	
	
	
	
	System.out.println("enter assignment marks");
	double assignment_marks=sc.nextDouble();
	ac.setAssignment_marks(assignment_marks);
	
	 double total=mpt_score+ mtt_score+assignment_marks;
	 System.out.println("trainee details"+ trainee_name+"total marks"+total);
	
	
em.persist(ac);
	
	
	System.out.println(" trainee details are added");
	
	
	em.getTransaction().commit();
	em.close();
	factory.close();
		
	}

}
