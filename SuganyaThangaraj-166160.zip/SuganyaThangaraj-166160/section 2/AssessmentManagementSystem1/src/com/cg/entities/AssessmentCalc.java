package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "calculation")

public class AssessmentCalc implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String trainee_name;
	private String module_name;
	private double mpt_score;
	private double mtt_score;
	private double assignment_marks;
	private double total;
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public String getTrainee_name() {
		return trainee_name;
	}
	public void setTrainee_name(String trainee_name) {
		this.trainee_name = trainee_name;
	}
	public String getModule_name() {
		return module_name;
	}
	public void setModule_name(String module_name) {
		this.module_name = module_name;
	}
	public double getMpt_score() {
		return mpt_score;
	}
	public void setMpt_score(double mpt_score) {
		this.mpt_score = mpt_score;
	}
	public double getMtt_score() {
		return mtt_score;
	}
	public void setMtt_score(double mtt_score) {
		this.mtt_score = mtt_score;
	}
	public double getAssignment_marks() {
		return assignment_marks;
	}
	public void setAssignment_marks(double assignment_marks) {
		this.assignment_marks = assignment_marks;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "AssessmentCalc [trainee_name=" + trainee_name + ", module_name=" + module_name + ", mpt_score="
				+ mpt_score + ", mtt_score=" + mtt_score + ", assignment_marks=" + assignment_marks + ", total=" + total
				+ "]";
	}
	
	
	

}
